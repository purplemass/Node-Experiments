from distutils.core import setup

setup(name = "websocket", py_modules = ["websocket"])
